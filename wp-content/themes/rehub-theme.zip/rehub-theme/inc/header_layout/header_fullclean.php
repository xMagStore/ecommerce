<!-- Logo section -->
<div class="logo_section_wrap">
    <div class="header_clean_style clearfix pt0 pb0">                      
        <?php if(rehub_option('rehub_ads_top')) : ?><?php echo do_shortcode(rehub_option('rehub_ads_top')); ?><?php endif; ?>                      
    </div>
</div>
<!-- /Logo section -->  