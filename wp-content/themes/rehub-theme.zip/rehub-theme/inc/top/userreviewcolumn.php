<?php if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}?>
<?php echo rehub_get_user_rate('admin') ; ?>