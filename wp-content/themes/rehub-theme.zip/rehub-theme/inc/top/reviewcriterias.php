<?php if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}?>
<div><?php echo rehub_exerpt_function(array('reviewcriterias'=> 'editor'));?></div>