<?php if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}?>
<?php echo re_user_rating_shortcode(array('size' => 'big')) ; ?>