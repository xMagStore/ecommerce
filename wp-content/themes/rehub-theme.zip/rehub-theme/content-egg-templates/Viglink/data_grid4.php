<?php
/*
  Name: Grid of products (4 column)
 */
?>
<?php $columnsgrid = 4;?>
<?php include(rh_locate_template('inc/ce_common/data_grid.php')); ?>